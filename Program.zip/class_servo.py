# class_servo.py — PCA9685 舵机驱动（接口与原 RS304MD 版一致）
#
# 唯一大幅改动的文件：原作者用 serial + RS304MD 二进制协议
#                   改为 I2C + PCA9685 PWM 占空比
#
# 接口方法保持原名：
#   ServoDriver  ← 原 sPort
#   Servo        ← 原 RS304MD
#     trq_set(status)             扭矩开关
#     control_time_rotate(angle,t) 定时旋转（非阻塞，与 RS304MD 行为一致）
#     control_rotate(angle)        直接旋转

import board
import busio
from adafruit_pca9685 import PCA9685
import time


class ServoDriver:
    def __init__(self, address=0x40):
        self.i2c = busio.I2C(board.SCL, board.SDA)
        self.pca = PCA9685(self.i2c, address=address)
        self.pca.frequency = 50

    def close(self):
        self.i2c.deinit()


class Servo:
    def __init__(self, driver, channel,
                 center_us=1500, us_per_90deg=500,
                 min_us=900, max_us=2100):
        self.driver = driver
        self.channel = channel
        self.center_us = center_us
        self.us_per_90deg = us_per_90deg
        self.min_us = min_us
        self.max_us = max_us

    def _angle_to_duty(self, angle):
        # RS304MD 原版は a = -angle*10 で反転していたため符号を合わせる
        pulse = self.center_us + (-angle) * (self.us_per_90deg / 90.0)
        pulse = max(self.min_us, min(self.max_us, pulse))
        return int(pulse / 20000.0 * 65535)

    def trq_set(self, status):
        if status == 0:
            self.driver.pca.channels[self.channel].duty_cycle = 0

    def control_rotate(self, angle):
        duty = self._angle_to_duty(angle)
        self.driver.pca.channels[self.channel].duty_cycle = duty

    def control_time_rotate(self, angle, t):
        # 非阻塞：设目标角度后立即返回（与原 RS304MD 行为一致）
        self.control_rotate(angle)