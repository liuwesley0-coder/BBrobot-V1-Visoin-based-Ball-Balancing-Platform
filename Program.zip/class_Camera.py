from picamera2 import Picamera2
import cv2
import numpy as np
import threading
import math
lock = threading.Lock()


class Camera:
    def __init__(self):
        #カメラの初期化と設定とスタート
        self.picam2 = Picamera2()
        self.height = 480
        self.width = 480
        self.config = self.picam2.create_video_configuration(
            main={"format": 'XRGB8888', "size": (self.height, self.width)},
            controls={
                "FrameDurationLimits": (8333, 8333),
                "ExposureTime": 8000
            }
        )
        self.picam2.configure(self.config)

        # 純霍夫円パラメータ（樹莓派 ov5647 チューニング済み）
        self.hough_dp     = 1.2
        self.hough_minDist = 40
        self.hough_param1  = 50
        self.hough_param2  = 35
        self.hough_minR    = 20
        self.hough_maxR    = 120

        #カメラをスタート（AWB/AE 安定のため暖機）
        self.picam2.start()
        import time
        time.sleep(1)

    def take_pic(self):
        frame = self.picam2.capture_array()
        return frame[:, :, 1:4]          # XRGB → BGR


    def show_video(self, image):
        if not hasattr(self, '_no_gui'):
            import os
            self._no_gui = "DISPLAY" not in os.environ
        if self._no_gui:
            return                       # SSH：完全跳过
        cv2.imshow("Live", image)
        cv2.waitKey(1)

    def find_ball(self, image):
        # ── 純霍夫円検出（樹莓派 ov5647 色再現が特殊なため HSV 不使用）──
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (9, 9), 2)

        circles = cv2.HoughCircles(
            blur, cv2.HOUGH_GRADIENT,
            dp=self.hough_dp, minDist=self.hough_minDist,
            param1=self.hough_param1, param2=self.hough_param2,
            minRadius=self.hough_minR, maxRadius=self.hough_maxR
        )

        if circles is not None:
            circles = np.uint16(np.around(circles))
            # 最初の円を採用（通常1個のみ）
            cx, cy, r = int(circles[0][0][0]), int(circles[0][0][1]), int(circles[0][0][2])
            area = int(math.pi * r * r)

            self.show_video(image)

            cx -= self.height / 2
            cy -= self.width / 2
            cx, cy = -cy, cx
            return int(cx), int(cy), area

        self.show_video(image)
        return -1, -1, 0


    def clean_up_cam(self):
        self.picam2.stop()
        self.picam2.close()