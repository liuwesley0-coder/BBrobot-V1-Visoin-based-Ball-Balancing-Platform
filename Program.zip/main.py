import class_BBRobot
import class_Camera
import class_PID
import time
import threading
import numpy as np

# 图像尺寸（高、宽）和通道数（此处为 3 个通道 = RGB）
height = 480
width = 640
channels = 3

# 创建一张空白图像（所有像素设为 0）
image = np.zeros((height, width, channels), dtype=np.uint8)


#机器人使用的舵机PCA9685通道
channels = [0, 1, 2]

#PID系数和决定φ大小的系数
K_PID = [0.03, 0.0002, 0.008]  # Kp↑高速应答/ Ki微増 / Kd↑制动强化
k = 1.5                         
a = 1                           # 低通滤波器（1=无效）
# 实例化机器人、相机和 PID 控制器
Robot = class_BBRobot.BBrobot(channels)
camera = class_Camera.Camera()
pid = class_PID.PID(K_PID, k, a)

#初始姿态根据安装位置下移30度
Robot.set_up()
pz_ini = Robot.ini_pos[2]


frame_count = 0
start_time = time.time()
img_start_time = time.time()
rob_start_time = time.time()
fps = 0  # 将 0 设为初始值
img_fps = 0
rob_fps = 0


#球坐标
x = -1
y = -1
area = -1
goal = [0, 0]    #球要在中心坐标处

def get_img():
    global image, img_fps, img_start_time
    img_frame_count = 0
    while(1):
        image = camera.take_pic()
        #img_fps 的计算
        img_frame_count += 1
        if img_frame_count == 100:
            img_end_time = time.time()
            img_elapsed_time = img_end_time - img_start_time
            img_fps = 100 / img_elapsed_time
            img_start_time = img_end_time
            img_frame_count = 0



def cont_rob():
    global x, y, area, rob_fps, rob_start_time
    rob_frame_count = 0
    miss_count = 0
    last_x, last_y, last_area = -1, -1, -1
    while(1):
        _x, _y, _area = camera.find_ball(image)
        if _x != -1:
            miss_count = 0
            x, y, area = _x, _y, _area
            last_x, last_y, last_area = _x, _y, _area
        else:
            miss_count += 1
            if miss_count <= 10:
                x, y, area = last_x, last_y, last_area
            else:
                x, y, area = -1, -1, -1   
        #rob_fps计算
        rob_frame_count += 1
        if rob_frame_count == 100:
            rob_end_time = time.time()
            rob_elapsed_time = rob_end_time - rob_start_time
            rob_fps = 100 / rob_elapsed_time
            rob_start_time = rob_end_time
            rob_frame_count = 0

try:
    camera_thread = threading.Thread(target=get_img)
    rob_thread = threading.Thread(target=cont_rob)
    camera_thread.start()
    rob_thread.start()

    while(1):
        _x, _y, _area = x, y, area      
        if _x != -1:
            theta, phi = pid.compute(goal, [_x, _y, _area])
            Robot.control_t_posture([theta, phi, pz_ini], 0.01)
            print(f"img_fps: {img_fps:.0f}, rob_fps: {rob_fps:.0f}  "
                  f"HIT x={_x:+d} y={_y:+d} area={_area}")
        else:
            print(f"img_fps: {img_fps:.0f}, rob_fps: {rob_fps:.0f}  MISS")

finally:
    Robot.clean_up()
    camera.clean_up_cam()